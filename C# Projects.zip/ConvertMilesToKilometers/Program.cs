﻿using System;
namespace ConvertMilesToKilometers
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Welcome to the Miles-to-Kilometers Conversion program!");
            string numberOfMiles;
            double numberOfMilesToDouble;
            
            static void CalculateKilometers(double numberOfMilesToDouble)
            {
                double kilometer = 1.60934;
                double calculation = numberOfMilesToDouble * kilometer;
                Console.WriteLine("\nThe number of kilometers converted from " + numberOfMilesToDouble + " miles" +
                    " is: " + calculation + " kilometers.");
            }

            for (int i = 4; i > 0; i--)
            {
                Console.Write("\nPlease enter the number of miles you want to convert: ");
                numberOfMiles = Console.ReadLine();
                numberOfMilesToDouble = Convert.ToDouble(numberOfMiles);
                CalculateKilometers(numberOfMilesToDouble);
                if (i > 1)
                {
                    Console.WriteLine("You have " + (i-1) + " more uses of this program.");
                }
            }
            Console.WriteLine("\nThanks for using the Miles-to-Kilometers Conversion program!\nGoodbye!");
        }
    }
}
