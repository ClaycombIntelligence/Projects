﻿using System;

namespace TestSoccerPlayer
{
    class Program
    {
            public class CreatePlayer
        {
            public string playerName;
            public int jerseyNum;
            public int goalsScored;
            public int assists;
            public Random rand = new Random();
            public string[] names = new string[] {"Joshua Claycomb","Sebastian Gilt","Wyatt Fowler","Mathew White","True McKenna"};
            
            public void GeneratePlayer()
            {
                playerName = names[rand.Next(0,4)];
                jerseyNum = rand.Next(1,40);
                goalsScored = rand.Next(1,35);
                assists = rand.Next(1,20);
            }
            public void DisplayPlayer()
            {
                Console.WriteLine("\nPlayer Name: " + playerName
                    + "\nJersey Number: " + jerseyNum
                    + "\nGoals Scored: " + goalsScored
                    + "\nTotal Assists: " + assists);
            }
        }
        static void Main()
        {
            string userInput;
            Console.WriteLine("Welcome to the Test Soccer Player program!");
            CreatePlayer soccerPlayer = new CreatePlayer();
            soccerPlayer.GeneratePlayer();
            soccerPlayer.DisplayPlayer();

            Console.Write("\nWould you like to generate another player? (Y/N): ");
            userInput = Console.ReadLine();
            if (userInput == "Y" || userInput == "y")
            {
                soccerPlayer.GeneratePlayer();
                soccerPlayer.DisplayPlayer();
                Console.WriteLine("\nThank you for using the Test Soccer Player program! Goodbye!");
            }
            else
            {
                Console.WriteLine("\nThank you for using the Test Soccer Player program! Goodbye!");
            }
        }
    }
}
