﻿using System;

namespace Lottery
{
    class Program
    {
        
        static void Main(string[] args)
        {
            double guessIndex;
            double guessOne = 0;
            double guessTwo = 0; 
            double guessThree = 0;
            string userInputAsString;
            double guessAttempts = 3;
            int SIZE = 3;
            int[] winningNumbers = new int[SIZE];
            Random rand = new Random();

            for (int i = 0; i < winningNumbers.Length; i++)
            {
                winningNumbers[i] = rand.Next(1,5);
            }

          Console.WriteLine("Winning Order: " + winningNumbers[0] + winningNumbers[1] + winningNumbers[2]);

            Console.WriteLine("\nWelcome to the Lottery Game!\n");
            for (guessIndex = 0; guessIndex < guessAttempts; guessIndex++)
            {
                Console.Write("Please enter your guess for #" + (guessIndex+1) + " (1-4): ");
                userInputAsString = Console.ReadLine();

                if (guessIndex == 0)
                {
                    guessOne = Convert.ToDouble(userInputAsString);
                }
                else if (guessIndex == 1)
                {
                    guessTwo = Convert.ToDouble(userInputAsString);
                }
                else if (guessIndex == 2)
                {
                    guessThree = Convert.ToDouble(userInputAsString);
                }
                while(Convert.ToDouble(userInputAsString) > 4 || Convert.ToDouble(userInputAsString) < 0)
                {
                    Console.Write("Please enter a valid number (1-4): ");
                    userInputAsString = Console.ReadLine();
                }
            }
            Console.WriteLine("\nRESULTS:\nUser Guess = " + guessOne + guessTwo + guessThree + "\nWinning Numbers: " + winningNumbers[0] + winningNumbers[1] + winningNumbers[2]);

            // 3 matches in order
            if (guessOne == winningNumbers[0] && guessTwo == winningNumbers[1] && guessThree == winningNumbers[2])
            {
                Console.WriteLine("\nCongratulations! You guessed all three numbers right in order! You've won $10,000!");
            }
            // Three matches, out of order
            else if (guessOne == winningNumbers[2] && guessTwo == winningNumbers[1] && guessThree == winningNumbers[0] ||
                    guessOne == winningNumbers[2] && guessTwo == winningNumbers[0] && guessThree == winningNumbers[1] ||
                    guessOne == winningNumbers[1] && guessTwo == winningNumbers[0] && guessThree == winningNumbers[2] ||
                    guessOne == winningNumbers[1] && guessTwo == winningNumbers[2] && guessThree == winningNumbers[0] ||
                    guessOne == winningNumbers[0] && guessTwo == winningNumbers[2] && guessThree == winningNumbers[1])
            {
                Console.WriteLine("Congratulations! You've guessed three numbers right, but out of order! You've won $1,000!");
            }
            // Two matches
            else if (guessOne == winningNumbers[0] && guessTwo == winningNumbers[2] ||
                guessOne == winningNumbers[0] && guessTwo == winningNumbers[1] ||
                 guessOne == winningNumbers[0] && guessThree == winningNumbers[2] ||
                 guessTwo == winningNumbers[1] && guessThree == winningNumbers[2])
            {
                Console.WriteLine("\nCongratulations! You've guessed two numbers right! You've won $100!");
            }
            // One match
            else if (guessOne == winningNumbers[0] || guessTwo == winningNumbers[1] || guessThree == winningNumbers[2])
            {
                Console.WriteLine("Congratulations! You've guessed one number correctly! You've won $10!");
            }
            // No matches
            else
            {
                Console.WriteLine("\nSorry! You didn't get any numbers correct, you've lost!");
            }
        }
    }
}
