﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessAWordGame
{
    public partial class Form1 : Form
    {
        public string secretWord;
        public string[] myWords = {"animal", "bottle", "critic", "double", "energy", "family", "growth", "heaven" };
        public const int maxLives = 5;
        public int livesLeft;
        public Random rand = new Random();
        public char c1; public char c2; public char c3; public char c4; public char c5; public char c6;
        public bool c1Guessed; public bool c2Guessed; public bool c3Guessed; 
        public bool c4Guessed; public bool c5Guessed; public bool c6Guessed;

        public Form1()
        {
            InitializeComponent();
        }

        public void Resetter()
        {
            secretWord = myWords[rand.Next(0, 8)];
            c1 = secretWord[0]; c2 = secretWord[1]; c3 = secretWord[2]; c4 = secretWord[3]; c5 = secretWord[4]; c6 = secretWord[5];
            c1Guessed = false; c2Guessed = false; c3Guessed = false; c4Guessed = false; c5Guessed = false; c6Guessed = false;
            MessageBox.Show("A new secret word has been generated!", "Guess A Word");
            livesLeft = maxLives;
            LifeLabel.Text = "Lives Left: " + livesLeft;
            missedCharLabel.Text = "";
            c1Label.Text = "*"; c2Label.Text = "*"; c3Label.Text = "*"; c4Label.Text = "*"; c5Label.Text = "*"; c6Label.Text = "*";
            //CheatLabel.Text = secretWord;
        }

        private void PlayButton_Click(object sender, EventArgs e)
        {
            secretWord = myWords[rand.Next(0, 8)];
            c1 = secretWord[0]; c2 = secretWord[1]; c3 = secretWord[2]; c4 = secretWord[3]; c5 = secretWord[4]; c6 = secretWord[5];
            livesLeft = maxLives;
            LifeLabel.Text = "Lives Left: " + livesLeft;
            c1Guessed = false; c2Guessed = false; c3Guessed = false; c4Guessed = false; c5Guessed = false; c6Guessed = false;
            //CheatLabel.Text = secretWord;
            MessageBox.Show("A new secret word has been generated!", "Guess A Word");
            PromptLabel.Text = "I'm thinking of a six letter word. What is it?";
            playButton.Visible = false;
            guessButton.Visible = true;
        }

        private void GuessButton_Click(object sender, EventArgs e)
        {
            if (guessTB.Text.Length > 1)
            {
                MessageBox.Show("You can only guess with one letter!", "Guess A Word");
            }

            if (missedCharLabel.Text.Contains(guessTB.Text))
            {
                MessageBox.Show("You've already tried this letter!\nPlease try again.","Guess A Word");
            }

            if (secretWord.Contains(guessTB.Text))
            {
                if(guessTB.Text == c1.ToString())
                {
                    c1Label.Text = c1.ToString();
                    c1Guessed = true;
                }
                if (guessTB.Text == c2.ToString())
                {
                    c2Label.Text = c2.ToString();
                    c2Guessed = true;
                }
                if (guessTB.Text == c3.ToString())
                {
                    c3Label.Text = c3.ToString();
                    c3Guessed = true;
                }
                if (guessTB.Text == c4.ToString())
                {
                    c4Label.Text = c4.ToString();
                    c4Guessed = true;
                }
                if (guessTB.Text == c5.ToString())
                {
                    c5Label.Text = c5.ToString();
                    c5Guessed = true;
                }
                if (guessTB.Text == c6.ToString())
                {
                    c6Label.Text = c6.ToString();
                    c6Guessed = true;
                }
                guessTB.Text = "";
            }
            else
            {
                livesLeft--;
                LifeLabel.Text = "Lives Left: " + livesLeft;
                missedCharLabel.Text += guessTB.Text;
                guessTB.Text = "";
            }

            if (c1Guessed && c2Guessed && c3Guessed && c4Guessed && c5Guessed && c6Guessed)
            {
                MessageBox.Show("Congratulations! You've won with " + livesLeft + " lives remaining!\nThe secret word was: " + secretWord +
                    "\nGame resetting...", "Guess A Word");
                Resetter();
            }

            if(livesLeft < 0)
            {
                livesLeft = 0;
                LifeLabel.Text = "Lives Left: " + livesLeft;
                MessageBox.Show("Unfortunately, you've lost!\nThe secret word was: " + secretWord 
                    + "\nGame resetting...","Guess A Word");
                Resetter();
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
