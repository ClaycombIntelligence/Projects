﻿namespace GuessAWordGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guessTB = new System.Windows.Forms.TextBox();
            this.LifeLabel = new System.Windows.Forms.Label();
            this.PromptLabel = new System.Windows.Forms.Label();
            this.playButton = new System.Windows.Forms.Button();
            this.guessButton = new System.Windows.Forms.Button();
            this.CheatLabel = new System.Windows.Forms.Label();
            this.c1Label = new System.Windows.Forms.Label();
            this.c2Label = new System.Windows.Forms.Label();
            this.c3Label = new System.Windows.Forms.Label();
            this.c4Label = new System.Windows.Forms.Label();
            this.c5Label = new System.Windows.Forms.Label();
            this.c6Label = new System.Windows.Forms.Label();
            this.missedCharLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // guessTB
            // 
            this.guessTB.Location = new System.Drawing.Point(25, 180);
            this.guessTB.Name = "guessTB";
            this.guessTB.Size = new System.Drawing.Size(100, 38);
            this.guessTB.TabIndex = 0;
            // 
            // LifeLabel
            // 
            this.LifeLabel.AutoSize = true;
            this.LifeLabel.BackColor = System.Drawing.SystemColors.Control;
            this.LifeLabel.Location = new System.Drawing.Point(25, 240);
            this.LifeLabel.Name = "LifeLabel";
            this.LifeLabel.Size = new System.Drawing.Size(152, 32);
            this.LifeLabel.TabIndex = 2;
            this.LifeLabel.Text = "Lives Left: ";
            this.LifeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PromptLabel
            // 
            this.PromptLabel.AutoSize = true;
            this.PromptLabel.BackColor = System.Drawing.SystemColors.Control;
            this.PromptLabel.Location = new System.Drawing.Point(25, 25);
            this.PromptLabel.Name = "PromptLabel";
            this.PromptLabel.Size = new System.Drawing.Size(486, 32);
            this.PromptLabel.TabIndex = 1;
            this.PromptLabel.Text = "Welcome to the Guess A Word game!";
            // 
            // playButton
            // 
            this.playButton.Location = new System.Drawing.Point(523, 225);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(109, 59);
            this.playButton.TabIndex = 3;
            this.playButton.Text = "Play!";
            this.playButton.UseVisualStyleBackColor = true;
            this.playButton.Click += new System.EventHandler(this.PlayButton_Click);
            // 
            // guessButton
            // 
            this.guessButton.Location = new System.Drawing.Point(150, 175);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(120, 50);
            this.guessButton.TabIndex = 4;
            this.guessButton.Text = "Guess!";
            this.guessButton.UseVisualStyleBackColor = true;
            this.guessButton.Visible = false;
            this.guessButton.Click += new System.EventHandler(this.GuessButton_Click);
            // 
            // CheatLabel
            // 
            this.CheatLabel.AutoSize = true;
            this.CheatLabel.Location = new System.Drawing.Point(25, 302);
            this.CheatLabel.Name = "CheatLabel";
            this.CheatLabel.Size = new System.Drawing.Size(0, 32);
            this.CheatLabel.TabIndex = 5;
            // 
            // c1Label
            // 
            this.c1Label.AutoSize = true;
            this.c1Label.BackColor = System.Drawing.SystemColors.Control;
            this.c1Label.Location = new System.Drawing.Point(25, 123);
            this.c1Label.Name = "c1Label";
            this.c1Label.Size = new System.Drawing.Size(26, 32);
            this.c1Label.TabIndex = 6;
            this.c1Label.Text = "*";
            this.c1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c2Label
            // 
            this.c2Label.AutoSize = true;
            this.c2Label.BackColor = System.Drawing.SystemColors.Control;
            this.c2Label.Location = new System.Drawing.Point(65, 123);
            this.c2Label.Name = "c2Label";
            this.c2Label.Size = new System.Drawing.Size(26, 32);
            this.c2Label.TabIndex = 7;
            this.c2Label.Text = "*";
            this.c2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c3Label
            // 
            this.c3Label.AutoSize = true;
            this.c3Label.BackColor = System.Drawing.SystemColors.Control;
            this.c3Label.Location = new System.Drawing.Point(105, 123);
            this.c3Label.Name = "c3Label";
            this.c3Label.Size = new System.Drawing.Size(26, 32);
            this.c3Label.TabIndex = 8;
            this.c3Label.Text = "*";
            this.c3Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c4Label
            // 
            this.c4Label.AutoSize = true;
            this.c4Label.BackColor = System.Drawing.SystemColors.Control;
            this.c4Label.Location = new System.Drawing.Point(145, 123);
            this.c4Label.Name = "c4Label";
            this.c4Label.Size = new System.Drawing.Size(26, 32);
            this.c4Label.TabIndex = 9;
            this.c4Label.Text = "*";
            this.c4Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c5Label
            // 
            this.c5Label.AutoSize = true;
            this.c5Label.BackColor = System.Drawing.SystemColors.Control;
            this.c5Label.Location = new System.Drawing.Point(185, 123);
            this.c5Label.Name = "c5Label";
            this.c5Label.Size = new System.Drawing.Size(26, 32);
            this.c5Label.TabIndex = 10;
            this.c5Label.Text = "*";
            this.c5Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c6Label
            // 
            this.c6Label.AutoSize = true;
            this.c6Label.BackColor = System.Drawing.SystemColors.Control;
            this.c6Label.Location = new System.Drawing.Point(225, 123);
            this.c6Label.Name = "c6Label";
            this.c6Label.Size = new System.Drawing.Size(26, 32);
            this.c6Label.TabIndex = 11;
            this.c6Label.Text = "*";
            this.c6Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // missedCharLabel
            // 
            this.missedCharLabel.AutoSize = true;
            this.missedCharLabel.BackColor = System.Drawing.SystemColors.Control;
            this.missedCharLabel.Location = new System.Drawing.Point(260, 70);
            this.missedCharLabel.Name = "missedCharLabel";
            this.missedCharLabel.Size = new System.Drawing.Size(0, 32);
            this.missedCharLabel.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(25, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 32);
            this.label1.TabIndex = 13;
            this.label1.Text = "Missed Letters:";
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(519, 302);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(113, 59);
            this.ExitButton.TabIndex = 15;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(668, 392);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.missedCharLabel);
            this.Controls.Add(this.c6Label);
            this.Controls.Add(this.c5Label);
            this.Controls.Add(this.c4Label);
            this.Controls.Add(this.c3Label);
            this.Controls.Add(this.c2Label);
            this.Controls.Add(this.c1Label);
            this.Controls.Add(this.CheatLabel);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.LifeLabel);
            this.Controls.Add(this.PromptLabel);
            this.Controls.Add(this.guessTB);
            this.Name = "Form1";
            this.Text = "Guess A Word!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox guessTB;
        private System.Windows.Forms.Label LifeLabel;
        private System.Windows.Forms.Label PromptLabel;
        private System.Windows.Forms.Button playButton;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.Label CheatLabel;
        private System.Windows.Forms.Label c1Label;
        private System.Windows.Forms.Label c2Label;
        private System.Windows.Forms.Label c3Label;
        private System.Windows.Forms.Label c4Label;
        private System.Windows.Forms.Label c5Label;
        private System.Windows.Forms.Label c6Label;
        private System.Windows.Forms.Label missedCharLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ExitButton;
    }
}

