﻿using System;
namespace SortWords
{
    class Program
    {
        public static void Main()
        {
            string[] myWords;
            string tempWord;
            int numberOfWords, i, j, length;
            Console.Write("Welcome to the Sort Words program!");
            Console.Write("\n\nInput number of strings you want to sort: ");
            numberOfWords = Convert.ToInt32(Console.ReadLine());
            myWords = new string[numberOfWords];
            Console.Write("Input {0} strings below : \n\n", numberOfWords);
            for (i = 0; i < numberOfWords; i++) {
                    myWords[i] = Console.ReadLine();
            }
            length = myWords.Length;
            for (i = 0; i < length; i++) {
                for (j = 0; j < length - 1; j++) {
                    if (myWords[j].CompareTo(myWords[j + 1]) > 0) {
                        tempWord = myWords[j];
                        myWords[j] = myWords[j + 1];
                        myWords[j + 1] = tempWord;
                    }
                }
            }
            Console.Write("\nYour strings have been sorted: \n\n");
            for (i = 0; i < length; i++) {
                Console.WriteLine(myWords[i] + " ");
            }
            Console.WriteLine("\nThank you for using the Sort Words program! Goodbye!");
        }
    }
}