﻿using System;

namespace PaintingEstimate
{
    class Program
    {
        public double wallHeight = 9;
        public double[] wallWidth = new double[4];
        public double[] wallLength = new double[4];
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Painting Estimate program!");
        }
    }
}
